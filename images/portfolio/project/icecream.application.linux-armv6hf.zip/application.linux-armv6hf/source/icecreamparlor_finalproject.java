import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 
import ddf.minim.ugens.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class icecreamparlor_finalproject extends PApplet {

Sky sky = new Sky();
Scoops scoops = new Scoops();;
Clouds clouds = new Clouds();
Cone cone;
int counter = 0;
int counter2 = 0;
PShape coneSvg;
PShape openSign;
PImage life, woodenWall, awning, checkMark,cloud, day, night, mute, loud, gameOverBackground;
Boolean shouldscore = false;
Scoreboard score = new Scoreboard();


Minim  minim;
Oscil wave;
Gain       gain;
AudioOutput out;
AudioPlayer backgroundMusic, catchScoop, dropScoop;
AudioPlayer angryMan1, angryMan2, angryMan3, angryMan4, angryMan5, angryMan6, angryMan7, youreFired, chaChing;
ArrayList<AudioPlayer> angryMan = new ArrayList<AudioPlayer>(); 
PFont chalkFont, regFont;
Scrollbar scroll;
RadioButton backgroundWidget;
int backgroundColor;
int[] skyColors = new  int[2];

public void setup(){
  skyColors[0] =  color(137,207,240);
  skyColors[1] =  color(10,0,102);
  backgroundColor = skyColors[sky.display()];
  background(backgroundColor);
  clouds.display();
  minim  = new Minim(this);
  backgroundMusic = minim.loadFile("data/mrplastic-hot-air-11027.mp3");
  catchScoop = minim.loadFile("data/catchScoop.mp3");
  dropScoop = minim.loadFile("data/dropScoop.mp3");
  youreFired = minim.loadFile("data/youreFired.mp3");
  chaChing =  minim.loadFile("data/chaChing.mp3");
 
  for (int i = 0; i < 7; i ++) {
    AudioPlayer player;
    player = minim.loadFile("data/angryMan"+(i+1)+".mp3");
    angryMan.add(player);
  }
  backgroundMusic.loop();
  //wave = new Oscil( 440, 0.5f, Waves.SINE );

  //gain = new Gain();

  //out = minim.getLineOut();

  //wave.patch(gain);
  //gain.patch(out);
  //backgroundMusic.play();
  //backgroundMusic.setGain(.5);
  // patch the file player to the output
 
 
                        
  frameRate(20);
  chalkFont = createFont("data/chalkFont.ttf", 30);
  regFont = createFont("data/regFont.ttf",50);
  checkMark = loadImage("data/x.png");
  
  
  scoops.loadShapes();
  //Cone(float xpos, float ypos, int speed)
  cone = new Cone((width-70)/2,height-100,10);
  cone.loadImages();
  clouds.load();
  life = loadImage("data/heart.png");
  frameRate(80);
  woodenWall = loadImage("data/woodenWall.jpg");
  awning = loadImage("data/awning2.png");
  openSign = loadShape("data/openSign.svg");
  night = loadImage("data/night.png");
  day = loadImage("data/day.png");
  mute = loadImage("data/mute.png");
  loud = loadImage("data/loud.png");
  
  scroll = new  Scrollbar(new PVector(84,174), -20, 40);
  backgroundWidget = new RadioButton(2, new PVector(390,174));
  backgroundWidget.createButtons();
  backgroundWidget.select(sky.display());
  frameRate(20);
  
  
}

public void draw(){
  if(!score.lost()){
    background(backgroundColor);
    clouds.display();
    cone.display();
    cone.move();
    scoops.display();
    image(woodenWall, 0, 0, width, 210);
    image(awning, -10, 210, width+10, 40);
    //noStroke(); 
    //fill(31,38,42);
    //ellipse(45,170,50,45);
    image(mute, 25, 151,50,50);
    image(loud, 248, 151,50,50);
    scroll.display();
    image(day, 325, 151,50,50);
    image(night, 405, 151,50,50);
    backgroundWidget.display();
    

    //translate(100,-140);
    //rotate(PI/8);
    //shape(openSign, width-150, 190,100, 75);
    
    score.display();

    shouldscore = cone.submit(scoops); 
    
  }else{
    
    //game over screen
    score.gameOver();
  }
 
  //noLoop();
}

public void stop()
{
// always close Minim audio classes
backgroundMusic.close();
//catchScoop.close();
// always stop Minim before exiting
minim.stop();
// The super.stop() makes sure that all the normal cleanup routines are done
super.stop();
}

public void keyPressed() {
    if (key == CODED){
      if (keyCode == LEFT){
        //println("debugL: "+cone.xpos);
        cone.moveLeft();
      } else  if (keyCode == RIGHT){
        //println("debugR: "+cone.xpos);
       cone.moveRight();
      }
    }
    if(score.lost() && key ==' '){
      //rstarts the game if on Game Over
      //println("debug");
      score = new Scoreboard();
      scoops = new Scoops();
      scoops.loadShapes();
    }   
}

public void mousePressed(){
  if (backgroundWidget.hover()>=0){
     int i = backgroundWidget.hover();
     println("pressed button ",i);
     backgroundWidget.select(i);
     sky.toggleColor(skyColors[i]);
  }
  if (scroll.button.hover()){
    scroll.grab = true;
  }
}

public void mouseReleased(){
  if (scroll.grab){
    scroll.grab = false;
    float value;
    if (mouseX>(scroll.position.x + scroll.w+10)){
      value = scroll.position.x + scroll.w;
    } else if (mouseX<(scroll.position.x-10)){
      value = scroll.position.x;
    }  else{
      value = mouseX;
    }
    scroll.buttonPosition.x = value;
 }
}

public void restartGame(){
  score = new Scoreboard();
  scoops = new Scoops();
  scoops.loadShapes();
}
class Cloud{
  PImage cloud;
  PVector position, size;
  
  
  Cloud(PImage cloud, PVector position, PVector size){
    this.cloud = loadImage("data/cloud.png");
    this.position = position;
    this.size = size;
  }
  
  public void move(){
    if (position.x>height+100){
        position.x = random(-200,-170);
    } else{
       position.x += 1;
    }
    image(cloud, position.x, position.y, size.x, size.y);
  }
}
class Clouds{
  int numClouds;
  ArrayList<Cloud> clouds = new ArrayList<Cloud>();
  
  Clouds(){
    this.numClouds = 8;
    this.clouds = new ArrayList<Cloud>();
  }
  
  public void load(){
     for (int i=0; i<numClouds; i++){
       Cloud currCloud = new Cloud(cloud, new PVector(random(-1,1)*80*i,150+i*80), new PVector (random(150,200), random(100,120)));
       clouds.add(currCloud);
      } 
      println(clouds.size());
  }
  
  public void display(){
    
       for (Cloud cloud : clouds){ 
           cloud.move();
       }
       
  }
}
class Cone {
  float xpos, ypos;
  int speed; 
  int numScoops; //should be equal to length of contents, but abi is initializing so she can write her code

  ArrayList<PImage> cones;
  PImage currentCone;

  
  Cone(float xpos, float ypos, int speed){
    this.xpos = xpos;
    this.ypos = ypos;
    this.speed = speed;
    numScoops = 0; //initalizes at empty


    cones = new ArrayList<PImage>();

  }
  
  public void loadImages(){
       String[] types = new String[]{"cone_1", "cone_2", "cone_3", "cone_reg_white", "cone_choco_white",
     "cone_reg_strawberry","cone_choco_strawberry", "cone_reg_mint", "cone_choco_mint"};
     
     for (int i=0; i<types.length; i++){
        String source = "data/" + types[i] + ".png";
        PImage img = loadImage(source);
        cones.add(img);
      }
      
      print(cones.size());
   }//ends loadImages
     
  
  public void display() {

    //println(score.level);
    currentCone = cones.get(score.level-1);
    image(currentCone, xpos, ypos,60,100);


  } 
  
  public boolean submit(Scoops curscoops) { 
   return curscoops.scoopstack.size() > 5;
  }
  
  public void move() {

    if(keyPressed && (keyCode == LEFT || keyCode == RIGHT)){
      if(this.xpos >= -60 && this.xpos <= width){
        this.xpos+=speed;
      }else if(this.xpos <-60){
         this.xpos = width-1; 
      }else{
         this.xpos = -59; 
      }
        
    }
  }
  
  public void moveLeft(){
      speed = -1*abs(speed);
  }
  public void moveRight(){
       speed = abs(speed);
  }
                
}    
  
  
class Message{
  String msg;
  PVector position;
  float start;
  float x;
  Message(String msg, PVector position, float start){
    this.msg = msg;
    this.position = position;
    this.start = start;
    this.x = 1;
  }
  
  public void display(){
    
   if (position.x<height+50 && -50<position.x){
    if (start > width/2){ //go left
       position.x -= 4;
    } else{
       position.x += 6;
    }
     position.y -= 4;
     textAlign(CENTER,CENTER);
     if (1/(2*x)<3){
        textFont(regFont, 50*(1/(2*x+.1f)));
     } else {
         textFont(regFont, 170);   
     }
     colorMode(RGB, 255, 255, 255, 1);
     fill(255,255,255,x);
     text(msg,position.x, position.y-100);
     colorMode(RGB, 255, 255, 255);
     
     //dim opacity
     if (x>=0){
       x -= .01f;
     }
   }}
  
  
}
class RadioButton{
  int numButtons, spacing;
  PVector position;
  ArrayList<RoundButton> buttons;
  RadioButton(int numButtons, PVector position){
    this.numButtons = numButtons;
    this.position = position;
    buttons = new ArrayList<RoundButton>();
    spacing = 80;
  }
  
  public void createButtons(){
    for (int i = 0; i<numButtons; i++){
        RoundButton b =new RoundButton(new PVector(position.x+i*spacing,position.y), new PVector(18,18), color(201,192,248));
        b.display();
        buttons.add(b);
      }
  }
  public void display(){
      for (int i = 0; i<numButtons; i++){
        RoundButton b =buttons.get(i);
        b.display();
      }
  }
  
  //checks if any of the buttons are being hover over
  public int hover(){
   for (int i = 0; i<buttons.size(); i++){
    RoundButton b = buttons.get(i);
    if (b.hover()){
        return PApplet.parseInt(i);
    }
  } return -1;
}
  
  public void select(int selected){
    println("num of buttons: ", buttons.size());
    for (int i = 0; i<numButtons; i++){
      if (i == selected){
         //println("selecting ",i);  
         //buttons.get(i).c = color(109,103,235);
         //buttons.get(i).c = color(121,130,187);
         //buttons.get(i).c = color(147,112,219);
         //buttons.get(i).c = color(21,18,55); //dark blue
         buttons.get(i).c = color(251,134,30); //orange
      } else{
        //println("reseting ", i);  
        buttons.get(i).c = color(201,192,248); //light purple
      }
    }
  }

}
class RoundButton{
   PVector position;
   PVector size;
   int c;
   
   RoundButton(PVector position, PVector size, int c){
     this.position = position;
     this.size = size;
     this.c = c;
   }
   
   public void display(){
    ellipseMode(CENTER);  
    float value;
    if (this.hover()){
      //c = color(250,220,254);
    } else{
      //c = color(121,130,187);
    }
    //stroke(color(hue(c)+10, saturation(c), brightness(c)));
    strokeWeight(3);
    //c = color(hue(c), value, brightness(c));
    fill(c);
    ellipse(position.x, position.y, size.x, size.y);
  }
  
  public boolean hover(){
    //check distance from mouse position to center of circle
    float distance = sqrt(sq(mouseX - position.x)  + sq(mouseY - position.y));
    // dist(mouseX,position.x);
    return (distance < size.x/2);
  }
  

}  
class Scoop{
  int id, levelOnStack;
  PVector position, offsetCone;
  float velocity;
  PShape shape;
  boolean caught;
  float angle;

  Scoop(int id, PShape shape){
    this.id = id;
    this.shape = shape;
    position = new PVector(id*52,-50);
    offsetCone = new PVector(-20,-40);
    velocity = 6*random(1,2); //pixels per frame
    // adding a small difference in velocities to make the cones fall at different times
    caught = false;  
    levelOnStack = 0;
    angle = 0;
}
  
  public void display(){
    //Draws scoop based on id, vel, pos
    pushMatrix();
    translate(position.x+50,position.y+50);
    rotate(angle);
    shape(shape, -50,-50, 100, 100); 
    popMatrix();
  }
  
  public void wiggle(float radian){
    println(radian);
    //Draws scoop based on id, vel, pos
    pushMatrix();
    translate(position.x+50,position.y+50);
    rotate(radian);
    shape(shape, -50,-50, 100, 100); 
    popMatrix();
  }
  
  public void move(){
    //makes scoop fall
    if (!caught){
      position.y += velocity;
      //reset velocity and position at top when it reaches the bottom of the screen
      if (position.y > height){
        if(id == score.createRequest().get(levelOnStack).id){
            //score.lives--;
        }
        position.y = -50;
        //position.x = random(50,450);
        int newId = PApplet.parseInt(random(scoops.shapes.length));
        id = newId;
        shape = scoops.shapes[id];
        //play random angry sound
       
        if (counter2%11 == 0 && !score.lost()){
          int idx;
          idx = counter%7;
          //println(idx);
          angryMan.get(idx).play();
          angryMan.get(idx).rewind();
          
          counter += 1;
        }
        counter2 += 1;
      }
      display();
    } 
    
    
  }
  
  public void discard(float dx){
    position.x += dx;
    position.y += velocity;
    velocity += 0.2f+0.05f*velocity;
    angle += radians(dx);
  }
  
  public void catchScoop(){
    //TO-DO: checks how close to the scoop is to the cone using their position attributes
    PVector collisionPoint = new PVector(cone.xpos+30,cone.ypos +30 - (levelOnStack*30+25));
    PVector bottom = new PVector (position.x+50,position.y+70);
    //ellipse(bottom.x,bottom.y,15,15);
    //rectMode(RADIUS);
    //rect(collisionPoint.x,collisionPoint.y,20,5);
    if (abs(collisionPoint.y - bottom.y) <10){
      if (abs(collisionPoint.x - bottom.x)<20){
        caught = true;
        //play sound
        catchScoop.play();
        catchScoop.rewind();
        //upping the contents;
        levelOnStack = cone.numScoops;
        cone.numScoops += 1;
      }
    }
  
         //TO-DO ASHWIN: add to scoreboard
      
    }
  
}
class Scoops{
   PShape[] shapes;

    ArrayList<Scoop> scoopList = new ArrayList<Scoop>();
    ArrayList<Scoop> scoopstack = new ArrayList<Scoop>();
    Scoop fallenScoop;

   
   Scoops(){
     this.shapes = new PShape[9];
   } 
   
   public void loadShapes(){
     String[] flavors = new String[]{"vanilla", "chocolate", "mint", "grape", "cherry","blueberry", "coffee","lemon","strawberry"};
     
     for (int i=0; i<shapes.length; i++){
        String source = "data/" + flavors[i] + ".svg";
        shapes[i] = loadShape(source);
        Scoop scoop = new Scoop(i,shapes[i]);
        scoopList.add(scoop);
      }
   }//ends loadShapes
   
 
   
   public void display(){
     for (Scoop scoop : scoopList){ 
       
        scoop.catchScoop();
        scoop.move();
        //make new scoop if scoop is caught
        if (scoop.caught){
          //create duplicate scoop to be stacked on cone
          Scoop newScoop = new Scoop(scoop.id,shapes[scoop.id]);
          newScoop.levelOnStack = scoop.levelOnStack;
          //add this duplicate scoop to the scoopstack
          scoopstack.add(newScoop);
        
          //reset the original scoop to top
            scoop.position.y = -50;
            //position.x = random(50,450);
            int newId = PApplet.parseInt(random(scoops.shapes.length));
            scoop.id = newId;
            scoop.shape = scoops.shapes[scoop.id];
            scoop.caught = false;
            scoop.velocity = (score.level+6)*random(1.3f,1.6f);
        }
      }
      
       if(fallenScoop != null){
           
           fallenScoop.discard(5);
           fallenScoop.display();
       }
       
      
   } // ends display()
   
   public void reset(){
       scoopstack.clear();
       cone.numScoops = 0;
   }
  
   
   
   
  public boolean meetsRequest(ArrayList<Scoop> request){
    for (int i = 0; i < scoopstack.size(); i ++){
         
      Scoop scoop = scoopstack.get(i);
      
      
          if (scoopstack.get(i).id != request.get(i).id){
            score.lives--;
            //play sound
            dropScoop.play();
            dropScoop.rewind();
            
            if(score.lost()){
              youreFired.play();
              youreFired.rewind();
            }
            //println("doesn't the request");
             scoop.position.x = cone.xpos+scoop.offsetCone.x;
             scoop.position.y = cone.ypos+scoop.offsetCone.y - scoop.levelOnStack*30;

            fallenScoop = scoop;
            fallenScoop.velocity = 0;

            reset();
            return false;
          } else {
            if (i == request.size()-1){
              chaChing.play();
              chaChing.rewind();
             println("GOOD JOB! you completed an order");

             // TO-DO : call scoreboard and add points
             reset();
             return true;
            }
          //println("matches for request");
           scoop.position.x = cone.xpos+scoop.offsetCone.x;
           scoop.position.y = cone.ypos+scoop.offsetCone.y - scoop.levelOnStack*30;
           //scoop.display();
           float probablility = random(0,1);
           if (probablility<.1f){
             scoop.wiggle(PI/12*random(-.75f,.75f));
           } else{
             scoop.display();
           }
            
           
          
           
           //draw a check
           
          image(checkMark, 48+25*i,50,30,30);
          }
          

     }
     
    
     return false;
 }
   
}
class Scoreboard{
  int points, lives, level, pointsRaised, topScore; //pointsRaised is how many points the player won in their last cone
  int[] request;
  ArrayList<Message> messages = new ArrayList<Message>();
  Boolean scoreSaved;
   
 Scoreboard(){
    points = 0;
    lives = 3;
    level = 1;
    topScore = 0;
    scoreSaved = false;
    // TO DO make the request larger when level advances
   
    request = new int[level];
    for (int i = 0; i < request.length ; i++){
      request[i] = PApplet.parseInt(random(scoops.shapes.length));
      //println(int(random(scoops.shapes.length)));
    }
 }

  // creates an array list of scoops according to the request
 public ArrayList<Scoop> createRequest(){
    int w = width-50;

     rectMode(CORNER);
     int h = 108;
     //stroke(161,91,205);
     //stroke(147,112,219);
     stroke(248,131,208);
     strokeWeight(6);

     fill(31,38,42);
     rect(25,30,w,h,10);
     fill(255);
     textAlign(RIGHT,CENTER);
     textFont(chalkFont, 30);
     text(points,w-25,h-40);
     textFont(chalkFont, 20);
     text("Level: "+level,w-25,h-5);
     
    ArrayList<Scoop> scoopsReq = new ArrayList<Scoop>();
    String[] flavors = new String[]{"vanilla", "chocolate", "mint", "grape", "cherry","blueberry", "coffee","lemon","strawberry"};
     for(int i = 0; i < request.length ; i++){
       //corrected some errors with having the right id
       String source = "data/" + flavors[request[i]] + ".svg";
       //print(flavors[request[i]]);
       PShape shape;
       shape = loadShape(source);
       Scoop temp = new Scoop(request[i],shape);
       scoopsReq.add(temp);
     }
     int d = 25;
     for(Scoop scoop : scoopsReq){
       scoop.position.x = 50+d;
       scoop.position.y = 78;
       pushMatrix();
       scale(0.5f);
       scoop.display();
       popMatrix();
       d+=50;
     }
     return scoopsReq;
 }
 
 // creates a brand new request 
 // this method is called whenever the user completes an order
 public void newRequest(){
   if(level < 9){
    request = new int[level];
   }else{
     request = new int[level];
   }
    for (int i = 0; i < request.length ; i++){
      request[i] = PApplet.parseInt(random(scoops.shapes.length));
      //println(int(random(scoops.shapes.length)));
    }
 }
 
 //displays the request and score
 public void display(){
     ArrayList<Scoop> scoopsReq = createRequest();
     if (scoops.meetsRequest(scoopsReq)){
         //gets new request
         upScore();
         newRequest();
     };
     for(int i = 0; i<lives; i++){
        image(life,50+32*i,90,16,16);
     }
     for (Message msg : messages){
       msg.display();
     }
     
 }
 
 //increates score and increases level
 // the level dictates the size of the order
 public void upScore(){
   pointsRaised = (request.length*100);
   points+= pointsRaised;  
   messages.add(new Message("+"+String.valueOf(pointsRaised),new PVector(cone.xpos, height-100),cone.xpos));
   if (level == 9){ //max size of request
       level = PApplet.parseInt(random(5,8));
   } else{
     level += 1;
   }
   return;
   /*
   Boolean correct = true;
   println();
    for(int i = 0; i < sc.scoopstack.size(); i++){
        if (sc.scoopstack.get(i).id != request[i]){
          correct = false;
        }
    }
    
    if(correct){
      points++;
      for (int i = 0; i < request.length ; i++){
        request[i] = int(random(scoops.shapes.length));
        //println(int(random(scoops.shapes.length)));
      
      }
    }
    
     sc.scoopstack.clear();
     */
 }
 

 
 public Boolean lost(){
     
     if (lives == 0){
       return true;
     }
     return false;
 }
 
 public void gameOver(){ 
     gameOverBackground = loadImage("data/gameOverBackground2.jpg");
     image(gameOverBackground, 0,0, width, height);
     rectMode(CENTER);
     
     stroke(255,199,240);
     strokeWeight(8);
     fill(31,38,42);
     rect(width/2,height/2, width-150, height-150,10);
     
    stroke(255);
    fill(255); 
    textFont(regFont, 50); 
    textAlign(CENTER,CENTER);
    text("GAME OVER", width/2, 200);
    textFont(regFont, 35); 
    String s = "SCORE: " + points;
    text(s,width/2,300);
    
    if(!scoreSaved){
      exportScore();
      scoreSaved = true;
    }
    s = "High Score: " + topScore;
    text(s,width/2,370);
    
    stroke(255,199,240);
    fill(245,166,224);
    rect(width/2,500,270,80,10);
    fill(255);
    text("RESTART",width/2,500);
    if((mouseX > width/2-150 && mouseX < width/2+150) && (mouseY > 500-50 && mouseY < 500+50)){
       cursor(HAND);
       if(mousePressed){
           restartGame();
           cursor(ARROW);
       }
    }
    else{
       cursor(ARROW); 
    }
    
 }
 
 public void restart(){
    points = 0;
    
 }
 
 public void exportScore(){
   
   Table highScores = loadTable("data/Scores.csv", "header");
   int[] scoreList = new int[highScores.getRowCount()+1]; 
   for(TableRow row : highScores.rows()){
       //println("Score: " + row.getInt("Score"));
   }
   TableRow newScore= highScores.addRow();
   newScore.setInt(highScores.getColumnCount()-1,points);
   println();
   int t = 0;
   for(TableRow row : highScores.rows()){
       println("Score: " + row.getInt("Score"));
       scoreList[t] = row.getInt("Score");
       t++;
   }
   println();
  saveTable(highScores,"data/Scores.csv");
  for(int sc : scoreList){
     println(sc); 
  }
  println();
  topScore = max(scoreList);
  
  
 }
 
  
}
class Scrollbar{
  int min, max, w;
  PVector position;
  PVector buttonPosition;
  RoundButton button;
  Boolean grab;
  Scrollbar(PVector position, int min, int max){
    this.position = position;
    this.min = min;
    this.max = max;
    buttonPosition = new PVector(position.x+150,position.y);
    w = 150; //default 300 pixels long
    grab = false;
  }
  
  public void display(){
     strokeWeight(4);
     stroke(color(200,204,231));
     line(position.x, position.y, position.x+w, position.y);
     
     if (grab){
       float value;
       if (mouseX>(scroll.position.x + scroll.w+10)){
          value = scroll.position.x + scroll.w;
          grab = false;
       } else if (mouseX<(scroll.position.x-10)){
          value = scroll.position.x;
          grab = false;
       }  else{
        value = mouseX;
       }
       buttonPosition.x = value;
       button = new RoundButton(new PVector(value, position.y), new PVector(20,20),color(195,185,249));
     } else{
     button = new RoundButton(buttonPosition, new PVector(18,18),color(251,134,30));
     }
     button.display();
     
     float value;
     //println((buttonPosition.x-position.x)/w);
     value = lerp(min-40,max,(buttonPosition.x-position.x)/w);
     //gain.setValue(value);
     backgroundMusic.setGain(value);
     //println(backgroundMusic.getGain());
     for (AudioPlayer man : angryMan) {
        man.setGain(value);
     }
     catchScoop.setGain(value); 
     dropScoop.setGain(value);
     youreFired.setGain(value);
     //println("if the min is",min,"and the max is",max,"then the button is at",value);
  }
  
  
    
}
class Sky{
  int day1 = color(69,177,232);
  int day2 = color(126,212,230);
  int evening1 = color(89,70,178);
  int evening2 = color(250,110,121);
  int night1 = color(0,28,61);
  int night2 = color(25,25,112);
  int morning1 =  color(105,53,156);
  int morning2 =  color(214,82,130);
  int c;
  Sky(){
    
  }
  
  public void toggleColor(int c){
    backgroundColor = c;
    /*
    if (backgroundColor == color(137,207,240)){
         backgroundColor = color(10,0,102);
       } else{
         backgroundColor = color(137,207,240);
       }*/
  }
  public int display(){
       int h = hour();
       int idx;
       if (20 < h || h < 8){
         idx = 1;
       } else{
         idx = 0;
       }
       return idx;
       
  }
  
  /*
  void display(color c1, color c2){
    noFill();  
    for (int i = 0; i <= 0+height; i++) {
      float inter = map(i, 0, height, 0, 1);
      color c = lerpColor(c1, c2, inter);
      stroke(c);
      line(0, i, width, i);
    }
  }*/
}
  public void settings() {  size(510,800); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "icecreamparlor_finalproject" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
